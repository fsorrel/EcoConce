CREATE DATABASE IF NOT EXISTS ecoconce_db;
USE ecoconce_db;

CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO roles (nombre) VALUES
('usuario'),
('admin'),
('mantenedor');

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rut VARCHAR(12) NOT NULL UNIQUE,
    nombre_alias VARCHAR(100) NOT NULL,
    correo VARCHAR(120) NOT NULL UNIQUE,
    contrasena VARCHAR(255) NOT NULL,
    comunidad VARCHAR(120) NOT NULL,
    direccion VARCHAR(200) NULL,
    latitud DECIMAL(10,7) NOT NULL,
    longitud DECIMAL(10,7) NOT NULL,
    puntos INT NOT NULL DEFAULT 0,
    rol_id INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (rol_id) REFERENCES roles(id)
);

CREATE TABLE puntos_reciclaje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    descripcion TEXT NOT NULL,
    comunidad VARCHAR(120) NOT NULL,
    direccion VARCHAR(200) NULL,
    latitud DECIMAL(10,7) NOT NULL,
    longitud DECIMAL(10,7) NOT NULL,
    estado ENUM('activo', 'en_mantenimiento', 'lleno', 'inactivo') NOT NULL DEFAULT 'activo',
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE materiales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion TEXT NOT NULL
);

INSERT INTO materiales (nombre, descripcion) VALUES
('Papel', 'Papel limpio y seco'),
('Cartón', 'Cartón limpio y doblado'),
('Botella de plástico', 'Botellas plásticas reciclables'),
('Botella de vidrio', 'Botellas de vidrio reciclables');

CREATE TABLE punto_materiales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    punto_id INT NOT NULL,
    material_id INT NOT NULL,
    capacidad_material_compactado INT NOT NULL DEFAULT 0,
    material_compactado_actual INT NOT NULL DEFAULT 0,
    FOREIGN KEY (punto_id) REFERENCES puntos_reciclaje(id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES materiales(id) ON DELETE CASCADE,
    UNIQUE (punto_id, material_id)
);

CREATE TABLE historial_punto_reciclaje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    punto_id INT NOT NULL,
    fecha DATE NOT NULL,
    material_id INT NOT NULL,
    material_compactado_recolectado INT NOT NULL,
    observacion VARCHAR(255) NULL,
    FOREIGN KEY (punto_id) REFERENCES puntos_reciclaje(id) ON DELETE CASCADE,
    FOREIGN KEY (material_id) REFERENCES materiales(id)
);

CREATE TABLE registros_reciclaje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    punto_id INT NOT NULL,
    material_id INT NOT NULL,
    cantidad_material_compactado INT NOT NULL,
    puntos_obtenidos INT NOT NULL DEFAULT 0,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (punto_id) REFERENCES puntos_reciclaje(id),
    FOREIGN KEY (material_id) REFERENCES materiales(id)
);

CREATE TABLE guias_reciclaje (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(150) NOT NULL,
    descripcion TEXT NOT NULL,
    contenido TEXT NOT NULL,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE canjes_recompensas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    recompensa VARCHAR(150) NOT NULL,
    puntos_usados INT NOT NULL,
    fecha_canje TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE reportes_puntos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    punto_id INT NOT NULL,
    tipo_reporte ENUM('lleno', 'dañado', 'cerrado', 'otro') NOT NULL,
    descripcion TEXT NULL,
    fecha_reporte TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (punto_id) REFERENCES puntos_reciclaje(id) ON DELETE CASCADE
);

INSERT INTO puntos_reciclaje (nombre, descripcion, comunidad, direccion, latitud, longitud, estado) VALUES
('Punto Verde Plaza Centro', 'Punto de reciclaje principal del sector centro', 'Concepción Centro', 'O Higgins 123', -36.8269900, -73.0497700, 'activo'),
('Punto Verde Barrio Norte', 'Punto orientado a botellas y cartón', 'Barrio Norte', 'Av. Norte 456', -36.8105000, -73.0352000, 'activo'),
('Punto Verde Laguna', 'Punto cercano a zonas residenciales con alta demanda', 'San Pedro', 'Av. Laguna Grande 88', -36.8402000, -73.1035000, 'en_mantenimiento');

INSERT INTO punto_materiales (punto_id, material_id, capacidad_material_compactado, material_compactado_actual) VALUES
(1, 1, 100, 25),
(1, 2, 120, 40),
(1, 3, 90, 18),
(1, 4, 80, 20),
(2, 1, 60, 10),
(2, 2, 70, 12),
(2, 3, 100, 35),
(2, 4, 50, 8),
(3, 1, 80, 30),
(3, 3, 120, 45);

INSERT INTO historial_punto_reciclaje (punto_id, fecha, material_id, material_compactado_recolectado, observacion) VALUES
(1, '2026-01-10', 1, 30, 'Retiro mensual de papel'),
(1, '2026-02-10', 2, 45, 'Retiro mensual de cartón'),
(1, '2026-03-10', 3, 20, 'Retiro mensual de plástico'),
(1, '2026-04-10', 4, 15, 'Retiro mensual de vidrio'),
(2, '2026-02-12', 1, 22, 'Operativo vecinal'),
(2, '2026-03-15', 3, 31, 'Recolección extraordinaria'),
(3, '2026-04-08', 1, 18, 'Mantenimiento preventivo');

INSERT INTO usuarios (rut, nombre_alias, correo, contrasena, comunidad, direccion, latitud, longitud, puntos, rol_id) VALUES
('12.345.678-9', 'Fernando', 'fernando@ecoconce.cl', '123456', 'Concepción Centro', NULL, -36.8270000, -73.0500000, 120, 1),
('11.111.111-1', 'AdminEco', 'admin@ecoconce.cl', 'admin123', 'Concepción Centro', 'Oficina Central 100', -36.8265000, -73.0485000, 0, 2),
('22.222.222-2', 'Mantencion1', 'mantenedor@ecoconce.cl', 'mant123', 'Barrio Norte', NULL, -36.8100000, -73.0350000, 0, 3);

INSERT INTO guias_reciclaje (titulo, descripcion, contenido) VALUES
('Separación de papel y cartón', 'Aprende a diferenciar residuos limpios y secos', 'Separa papel y cartón sin restos orgánicos y mantenlos secos.'),
('Uso responsable de puntos verdes', 'Buenas prácticas al reciclar', 'Revisa el estado del punto, respeta los materiales aceptados y compacta correctamente antes de depositar.');
