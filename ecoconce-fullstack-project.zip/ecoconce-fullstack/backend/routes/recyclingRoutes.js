import { Router } from 'express'
import { createRecyclingRecord, getMaterials, getRecyclingRecords } from '../controllers/recyclingController.js'

const router = Router()
router.get('/materiales', getMaterials)
router.get('/registros', getRecyclingRecords)
router.post('/registros', createRecyclingRecord)
export default router
