import { Router } from 'express'
import { createPoint, getPointHistory, getPointMaterials, getPoints } from '../controllers/pointController.js'

const router = Router()
router.get('/', getPoints)
router.post('/', createPoint)
router.get('/:id/materiales', getPointMaterials)
router.get('/:id/historial', getPointHistory)
export default router
