export const getHealth = async (_req, res) => {
  res.json({ ok: true, app: 'EcoConce API' })
}
