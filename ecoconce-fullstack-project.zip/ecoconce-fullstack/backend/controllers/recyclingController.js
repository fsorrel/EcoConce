import { pool } from '../config/db.js'

export const getMaterials = async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM materiales ORDER BY nombre ASC')
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener materiales', error: error.message })
  }
}

export const createRecyclingRecord = async (req, res) => {
  try {
    const { usuario_id, punto_id, material_id, cantidad_material_compactado } = req.body
    if (!usuario_id || !punto_id || !material_id || !cantidad_material_compactado) {
      return res.status(400).json({ message: 'Faltan campos obligatorios del registro' })
    }

    const puntosObtenidos = Number(cantidad_material_compactado) * 5

    const [result] = await pool.query(
      `INSERT INTO registros_reciclaje (usuario_id, punto_id, material_id, cantidad_material_compactado, puntos_obtenidos)
       VALUES (?, ?, ?, ?, ?)`,
      [usuario_id, punto_id, material_id, cantidad_material_compactado, puntosObtenidos]
    )

    await pool.query('UPDATE usuarios SET puntos = puntos + ? WHERE id = ?', [puntosObtenidos, usuario_id])
    await pool.query(
      'UPDATE punto_materiales SET material_compactado_actual = material_compactado_actual + ? WHERE punto_id = ? AND material_id = ?',
      [cantidad_material_compactado, punto_id, material_id]
    )

    const [rows] = await pool.query('SELECT * FROM registros_reciclaje WHERE id = ?', [result.insertId])
    res.status(201).json(rows[0])
  } catch (error) {
    res.status(500).json({ message: 'Error al registrar reciclaje', error: error.message })
  }
}

export const getRecyclingRecords = async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT rr.id, u.nombre_alias AS usuario, p.nombre AS punto, m.nombre AS material, rr.cantidad_material_compactado, rr.puntos_obtenidos, rr.fecha_registro
       FROM registros_reciclaje rr
       INNER JOIN usuarios u ON u.id = rr.usuario_id
       INNER JOIN puntos_reciclaje p ON p.id = rr.punto_id
       INNER JOIN materiales m ON m.id = rr.material_id
       ORDER BY rr.fecha_registro DESC`
    )
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener registros', error: error.message })
  }
}
