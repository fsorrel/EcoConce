import { pool } from '../config/db.js'

export const registerUser = async (req, res) => {
  try {
    const { rut, nombre_alias, correo, contrasena, comunidad, direccion, latitud, longitud } = req.body

    if (!rut || !nombre_alias || !correo || !contrasena || !comunidad || latitud === undefined || longitud === undefined) {
      return res.status(400).json({ message: 'Faltan campos obligatorios' })
    }

    const [result] = await pool.query(
      `INSERT INTO usuarios (rut, nombre_alias, correo, contrasena, comunidad, direccion, latitud, longitud, rol_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)`,
      [rut, nombre_alias, correo, contrasena, comunidad, direccion || null, latitud, longitud]
    )

    const [rows] = await pool.query('SELECT id, rut, nombre_alias, correo, comunidad, direccion, latitud, longitud, puntos, rol_id, fecha_registro FROM usuarios WHERE id = ?', [result.insertId])
    res.status(201).json(rows[0])
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ message: 'El usuario ya existe con ese rut o correo' })
    }
    res.status(500).json({ message: 'Error al registrar usuario', error: error.message })
  }
}

export const loginUser = async (req, res) => {
  try {
    const { correo, contrasena } = req.body
    const [rows] = await pool.query(
      'SELECT id, rut, nombre_alias, correo, comunidad, direccion, latitud, longitud, puntos, rol_id FROM usuarios WHERE correo = ? AND contrasena = ?',
      [correo, contrasena]
    )

    if (!rows.length) {
      return res.status(401).json({ message: 'Credenciales inválidas' })
    }

    res.json(rows[0])
  } catch (error) {
    res.status(500).json({ message: 'Error al iniciar sesión', error: error.message })
  }
}

export const getUsers = async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT u.id, u.rut, u.nombre_alias, u.correo, u.comunidad, u.direccion, u.latitud, u.longitud, u.puntos, r.nombre AS rol
       FROM usuarios u
       INNER JOIN roles r ON r.id = u.rol_id
       ORDER BY u.id DESC`
    )
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener usuarios', error: error.message })
  }
}
