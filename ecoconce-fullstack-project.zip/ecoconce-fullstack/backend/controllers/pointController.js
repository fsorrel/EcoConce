import { pool } from '../config/db.js'

export const getPoints = async (_req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT id, nombre, descripcion, comunidad, direccion, latitud, longitud, estado, fecha_creacion
       FROM puntos_reciclaje
       ORDER BY id ASC`
    )
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener puntos', error: error.message })
  }
}

export const getPointMaterials = async (req, res) => {
  try {
    const { id } = req.params
    const [rows] = await pool.query(
      `SELECT pm.id, m.nombre, m.descripcion, pm.capacidad_material_compactado, pm.material_compactado_actual
       FROM punto_materiales pm
       INNER JOIN materiales m ON m.id = pm.material_id
       WHERE pm.punto_id = ?
       ORDER BY m.nombre`,
      [id]
    )
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener materiales del punto', error: error.message })
  }
}

export const getPointHistory = async (req, res) => {
  try {
    const { id } = req.params
    const [rows] = await pool.query(
      `SELECT h.id, h.fecha, m.nombre AS material, h.material_compactado_recolectado, h.observacion
       FROM historial_punto_reciclaje h
       INNER JOIN materiales m ON m.id = h.material_id
       WHERE h.punto_id = ?
       ORDER BY h.fecha DESC`,
      [id]
    )
    res.json(rows)
  } catch (error) {
    res.status(500).json({ message: 'Error al obtener historial del punto', error: error.message })
  }
}

export const createPoint = async (req, res) => {
  try {
    const { nombre, descripcion, comunidad, direccion, latitud, longitud, estado } = req.body
    if (!nombre || !descripcion || !comunidad || latitud === undefined || longitud === undefined) {
      return res.status(400).json({ message: 'Faltan campos obligatorios del punto' })
    }
    const [result] = await pool.query(
      `INSERT INTO puntos_reciclaje (nombre, descripcion, comunidad, direccion, latitud, longitud, estado)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [nombre, descripcion, comunidad, direccion || null, latitud, longitud, estado || 'activo']
    )
    const [rows] = await pool.query('SELECT * FROM puntos_reciclaje WHERE id = ?', [result.insertId])
    res.status(201).json(rows[0])
  } catch (error) {
    res.status(500).json({ message: 'Error al crear punto', error: error.message })
  }
}
