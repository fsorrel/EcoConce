import express from 'express'
import cors from 'cors'
import healthRoutes from './routes/healthRoutes.js'
import userRoutes from './routes/userRoutes.js'
import pointRoutes from './routes/pointRoutes.js'
import recyclingRoutes from './routes/recyclingRoutes.js'

const app = express()
const port = Number(process.env.PORT || 4000)

app.use(cors())
app.use(express.json())

app.use('/api/health', healthRoutes)
app.use('/api/users', userRoutes)
app.use('/api/points', pointRoutes)
app.use('/api/recycling', recyclingRoutes)

app.listen(port, () => {
  console.log(`EcoConce API corriendo en http://localhost:${port}`)
})
