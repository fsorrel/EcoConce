# EcoConce Full Stack

Proyecto full stack de una app de reciclaje con frontend en React + Vite, backend en Node.js + Express y base de datos MySQL.

## Incluye

- Registro de usuario con comunidad obligatoria
- Dirección opcional
- Ubicación GPS obligatoria
- Inicio de sesión
- Panel de usuario
- Registro de reciclaje con material compactado
- Priorización visual de puntos por cercanía
- Panel admin
- Historial de puntos de reciclaje
- SQL completo con datos de ejemplo

## Estructura

- `frontend/` Aplicación React
- `backend/` API Express
- `backend/db/schema.sql` Base de datos completa

## 1. Crear la base de datos

Abre MySQL y ejecuta:

```sql
SOURCE backend/db/schema.sql;
```

Si `SOURCE` no te funciona, abre el archivo `backend/db/schema.sql`, copia todo y ejecútalo directamente.

## 2. Levantar backend

```bash
cd backend
npm install
cp .env.example .env
npm run dev
```

Asegúrate de editar `.env` con tus datos de MySQL.

## 3. Levantar frontend

```bash
cd frontend
npm install
npm run dev
```

## Accesos de prueba

### Admin
- correo: `admin@ecoconce.cl`
- contraseña: `admin123`

### Usuario
- correo: `fernando@ecoconce.cl`
- contraseña: `123456`

## API

### Salud
- `GET /api/health`

### Usuarios
- `GET /api/users`
- `POST /api/users/register`
- `POST /api/users/login`

### Puntos
- `GET /api/points`
- `POST /api/points`
- `GET /api/points/:id/materiales`
- `GET /api/points/:id/historial`

### Reciclaje
- `GET /api/recycling/materiales`
- `GET /api/recycling/registros`
- `POST /api/recycling/registros`

## Notas

- Las contraseñas están en texto plano para dejarlo simple y funcional para entrega/prototipo.
- Si después quieres, te lo puedo dejar con JWT, bcrypt y rutas protegidas.
- La interfaz está hecha como base visual completa del proyecto EcoConce y puede seguir creciendo por módulos.
