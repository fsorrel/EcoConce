const API_URL = 'http://localhost:4000/api'

export const api = {
  getHealth: async () => fetch(`${API_URL}/health`).then(r => r.json()),
  registerUser: async data => fetch(`${API_URL}/users/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(async r => {
    const data = await r.json()
    if (!r.ok) throw new Error(data.message || 'Error en registro')
    return data
  }),
  loginUser: async data => fetch(`${API_URL}/users/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(async r => {
    const data = await r.json()
    if (!r.ok) throw new Error(data.message || 'Error en login')
    return data
  }),
  getUsers: async () => fetch(`${API_URL}/users`).then(r => r.json()),
  getPoints: async () => fetch(`${API_URL}/points`).then(r => r.json()),
  createPoint: async data => fetch(`${API_URL}/points`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(async r => {
    const data = await r.json()
    if (!r.ok) throw new Error(data.message || 'Error al crear punto')
    return data
  }),
  getPointMaterials: async id => fetch(`${API_URL}/points/${id}/materiales`).then(r => r.json()),
  getPointHistory: async id => fetch(`${API_URL}/points/${id}/historial`).then(r => r.json()),
  getMaterials: async () => fetch(`${API_URL}/recycling/materiales`).then(r => r.json()),
  getRecords: async () => fetch(`${API_URL}/recycling/registros`).then(r => r.json()),
  createRecord: async data => fetch(`${API_URL}/recycling/registros`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).then(async r => {
    const data = await r.json()
    if (!r.ok) throw new Error(data.message || 'Error al registrar reciclaje')
    return data
  })
}
