import AdminPanel from '../components/AdminPanel'
import PointDetail from '../components/PointDetail'

export default function AdminPage({ points, selectedPoint, onSelectPoint, onPointCreated }) {
  return (
    <div className="main-grid admin-main">
      <AdminPanel points={points} onPointCreated={onPointCreated} onSelectPoint={onSelectPoint} />
      <PointDetail point={selectedPoint} adminMode />
    </div>
  )
}
