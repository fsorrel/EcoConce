import Hero from '../components/Hero'
import PointsList from '../components/PointsList'
import PointDetail from '../components/PointDetail'

export default function HomePage({ points, user, selectedPoint, onSelectPoint }) {
  return (
    <>
      <Hero />
      <div className="main-grid">
        <PointsList points={points} user={user} onSelectPoint={onSelectPoint} />
        <PointDetail point={selectedPoint} adminMode={false} />
      </div>
    </>
  )
}
