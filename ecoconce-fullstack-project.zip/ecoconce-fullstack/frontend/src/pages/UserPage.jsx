import RecyclingForm from '../components/RecyclingForm'
import PointDetail from '../components/PointDetail'
import PointsList from '../components/PointsList'

export default function UserPage({ user, points, selectedPoint, onSelectPoint, onRefresh }) {
  return (
    <section className="user-layout">
      <div className="card">
        <h3>Bienvenido, {user.nombre_alias}</h3>
        <p><strong>Comunidad:</strong> {user.comunidad}</p>
        <p><strong>Dirección:</strong> {user.direccion || 'No registrada'}</p>
        <p><strong>GPS:</strong> {user.latitud}, {user.longitud}</p>
        <p><strong>Puntos acumulados:</strong> {user.puntos}</p>
      </div>
      <RecyclingForm user={user} points={points} onCreated={onRefresh} />
      <div className="main-grid">
        <PointsList points={points} user={user} onSelectPoint={onSelectPoint} />
        <PointDetail point={selectedPoint} adminMode={false} />
      </div>
    </section>
  )
}
