import { useEffect, useState } from 'react'
import { api } from '../services/api'

export default function PointDetail({ point, adminMode }) {
  const [materials, setMaterials] = useState([])
  const [history, setHistory] = useState([])

  useEffect(() => {
    if (!point) return
    api.getPointMaterials(point.id).then(setMaterials)
    api.getPointHistory(point.id).then(setHistory)
  }, [point])

  if (!point) {
    return (
      <section className="card">
        <h3>Detalle del punto</h3>
        <p>Selecciona un punto para ver materiales e historial.</p>
      </section>
    )
  }

  return (
    <section className="card">
      <h3>Detalle de {point.nombre}</h3>
      <div className="detail-grid">
        <div>
          <h4>Materiales aceptados</h4>
          <ul className="plain-list">
            {materials.map(item => (
              <li key={item.id}>
                <strong>{item.nombre}</strong> · {item.material_compactado_actual}/{item.capacidad_material_compactado} materiales compactados
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4>{adminMode ? 'Historial operativo del punto' : 'Últimos movimientos'}</h4>
          <ul className="plain-list">
            {history.map(item => (
              <li key={item.id}>
                <strong>{item.fecha}</strong> · {item.material} · {item.material_compactado_recolectado} materiales compactados
                <br />
                <span>{item.observacion}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
