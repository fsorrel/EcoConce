import { useEffect, useState } from 'react'
import { api } from '../services/api'

export default function RecyclingForm({ user, points, onCreated }) {
  const [materials, setMaterials] = useState([])
  const [form, setForm] = useState({ punto_id: '', material_id: '', cantidad_material_compactado: '' })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  useEffect(() => {
    api.getMaterials().then(setMaterials)
  }, [])

  const handleChange = event => {
    setForm({ ...form, [event.target.name]: event.target.value })
  }

  const handleSubmit = async event => {
    event.preventDefault()
    setError('')
    setMessage('')

    try {
      const response = await api.createRecord({
        usuario_id: user.id,
        punto_id: Number(form.punto_id),
        material_id: Number(form.material_id),
        cantidad_material_compactado: Number(form.cantidad_material_compactado)
      })
      setMessage(`Registro guardado. Ganaste ${response.puntos_obtenidos} puntos.`)
      setForm({ punto_id: '', material_id: '', cantidad_material_compactado: '' })
      onCreated()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="card form-card">
      <h3>Registrar reciclaje</h3>
      <form className="form-grid" onSubmit={handleSubmit}>
        <select name="punto_id" value={form.punto_id} onChange={handleChange} required>
          <option value="">Selecciona un punto</option>
          {points.map(point => <option key={point.id} value={point.id}>{point.nombre}</option>)}
        </select>
        <select name="material_id" value={form.material_id} onChange={handleChange} required>
          <option value="">Selecciona un material</option>
          {materials.map(material => <option key={material.id} value={material.id}>{material.nombre}</option>)}
        </select>
        <input name="cantidad_material_compactado" type="number" min="1" placeholder="Cantidad de material compactado" value={form.cantidad_material_compactado} onChange={handleChange} required />
        <button type="submit">Guardar reciclaje</button>
      </form>
      {message && <p className="success">{message}</p>}
      {error && <p className="error">{error}</p>}
    </section>
  )
}
