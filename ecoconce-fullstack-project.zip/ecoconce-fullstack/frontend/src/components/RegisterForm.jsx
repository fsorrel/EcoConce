import { useState } from 'react'
import { api } from '../services/api'

export default function RegisterForm({ onRegister }) {
  const [form, setForm] = useState({
    rut: '',
    nombre_alias: '',
    correo: '',
    contrasena: '',
    comunidad: '',
    direccion: '',
    latitud: '',
    longitud: ''
  })
  const [status, setStatus] = useState('')
  const [error, setError] = useState('')

  const handleChange = event => {
    setForm({ ...form, [event.target.name]: event.target.value })
  }

  const getLocation = () => {
    if (!navigator.geolocation) {
      setError('Tu navegador no soporta geolocalización')
      return
    }

    navigator.geolocation.getCurrentPosition(
      position => {
        setForm(prev => ({
          ...prev,
          latitud: position.coords.latitude.toFixed(7),
          longitud: position.coords.longitude.toFixed(7)
        }))
        setError('')
      },
      () => setError('No se pudo obtener la ubicación GPS')
    )
  }

  const handleSubmit = async event => {
    event.preventDefault()
    setError('')
    setStatus('')

    try {
      const newUser = await api.registerUser({
        ...form,
        latitud: Number(form.latitud),
        longitud: Number(form.longitud)
      })
      setStatus('Usuario registrado correctamente')
      onRegister({ ...newUser, contrasena: form.contrasena })
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="card form-card">
      <h3>Registro de usuario</h3>
      <form className="form-grid" onSubmit={handleSubmit}>
        <input name="rut" placeholder="RUT" value={form.rut} onChange={handleChange} required />
        <input name="nombre_alias" placeholder="Nombre o alias" value={form.nombre_alias} onChange={handleChange} required />
        <input name="correo" type="email" placeholder="Correo" value={form.correo} onChange={handleChange} required />
        <input name="contrasena" type="password" placeholder="Contraseña" value={form.contrasena} onChange={handleChange} required />
        <input name="comunidad" placeholder="Comunidad" value={form.comunidad} onChange={handleChange} required />
        <input name="direccion" placeholder="Dirección opcional" value={form.direccion} onChange={handleChange} />
        <input name="latitud" placeholder="Latitud GPS" value={form.latitud} onChange={handleChange} required />
        <input name="longitud" placeholder="Longitud GPS" value={form.longitud} onChange={handleChange} required />
        <button type="button" className="secondary" onClick={getLocation}>Usar mi ubicación</button>
        <button type="submit">Crear cuenta</button>
      </form>
      {status && <p className="success">{status}</p>}
      {error && <p className="error">{error}</p>}
    </section>
  )
}
