import { useEffect, useState } from 'react'
import { api } from '../services/api'

export default function AdminPanel({ points, onPointCreated, onSelectPoint }) {
  const [users, setUsers] = useState([])
  const [records, setRecords] = useState([])
  const [form, setForm] = useState({
    nombre: '',
    descripcion: '',
    comunidad: '',
    direccion: '',
    latitud: '',
    longitud: '',
    estado: 'activo'
  })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const loadAdminData = async () => {
    const [usersData, recordsData] = await Promise.all([api.getUsers(), api.getRecords()])
    setUsers(usersData)
    setRecords(recordsData)
  }

  useEffect(() => {
    loadAdminData()
  }, [])

  const handleChange = event => {
    setForm({ ...form, [event.target.name]: event.target.value })
  }

  const handleSubmit = async event => {
    event.preventDefault()
    setMessage('')
    setError('')

    try {
      await api.createPoint({
        ...form,
        latitud: Number(form.latitud),
        longitud: Number(form.longitud)
      })
      setMessage('Punto creado correctamente')
      setForm({ nombre: '', descripcion: '', comunidad: '', direccion: '', latitud: '', longitud: '', estado: 'activo' })
      onPointCreated()
      loadAdminData()
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="admin-layout">
      <div className="card form-card">
        <h3>Crear punto de reciclaje</h3>
        <form className="form-grid" onSubmit={handleSubmit}>
          <input name="nombre" placeholder="Nombre" value={form.nombre} onChange={handleChange} required />
          <input name="descripcion" placeholder="Descripción" value={form.descripcion} onChange={handleChange} required />
          <input name="comunidad" placeholder="Comunidad" value={form.comunidad} onChange={handleChange} required />
          <input name="direccion" placeholder="Dirección opcional" value={form.direccion} onChange={handleChange} />
          <input name="latitud" placeholder="Latitud" value={form.latitud} onChange={handleChange} required />
          <input name="longitud" placeholder="Longitud" value={form.longitud} onChange={handleChange} required />
          <select name="estado" value={form.estado} onChange={handleChange}>
            <option value="activo">activo</option>
            <option value="en_mantenimiento">en_mantenimiento</option>
            <option value="lleno">lleno</option>
            <option value="inactivo">inactivo</option>
          </select>
          <button type="submit">Crear punto</button>
        </form>
        {message && <p className="success">{message}</p>}
        {error && <p className="error">{error}</p>}
      </div>

      <div className="card">
        <h3>Usuarios registrados</h3>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Alias</th>
                <th>Comunidad</th>
                <th>Rol</th>
                <th>Puntos</th>
              </tr>
            </thead>
            <tbody>
              {users.map(user => (
                <tr key={user.id}>
                  <td>{user.nombre_alias}</td>
                  <td>{user.comunidad}</td>
                  <td>{user.rol}</td>
                  <td>{user.puntos}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3>Registros recientes</h3>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Usuario</th>
                <th>Punto</th>
                <th>Material</th>
                <th>Compactado</th>
                <th>Puntos</th>
              </tr>
            </thead>
            <tbody>
              {records.map(record => (
                <tr key={record.id}>
                  <td>{record.usuario}</td>
                  <td>{record.punto}</td>
                  <td>{record.material}</td>
                  <td>{record.cantidad_material_compactado}</td>
                  <td>{record.puntos_obtenidos}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="card">
        <h3>Historial por punto</h3>
        <div className="point-grid">
          {points.map(point => (
            <article key={point.id} className="point-card compact">
              <h4>{point.nombre}</h4>
              <p>{point.comunidad}</p>
              <button onClick={() => onSelectPoint(point)}>Ver historial</button>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
