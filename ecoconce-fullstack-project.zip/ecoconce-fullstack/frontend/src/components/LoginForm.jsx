import { useState } from 'react'
import { api } from '../services/api'

export default function LoginForm({ onLogin }) {
  const [correo, setCorreo] = useState('')
  const [contrasena, setContrasena] = useState('')
  const [error, setError] = useState('')

  const handleSubmit = async event => {
    event.preventDefault()
    setError('')
    try {
      const user = await api.loginUser({ correo, contrasena })
      onLogin({ ...user, contrasena })
    } catch (err) {
      setError(err.message)
    }
  }

  return (
    <section className="card form-card">
      <h3>Ingreso al sistema</h3>
      <form className="form-grid" onSubmit={handleSubmit}>
        <input type="email" placeholder="Correo" value={correo} onChange={e => setCorreo(e.target.value)} required />
        <input type="password" placeholder="Contraseña" value={contrasena} onChange={e => setContrasena(e.target.value)} required />
        <button type="submit">Ingresar</button>
      </form>
      <p className="hint">Prueba admin: admin@ecoconce.cl / admin123</p>
      <p className="hint">Prueba usuario: fernando@ecoconce.cl / 123456</p>
      {error && <p className="error">{error}</p>}
    </section>
  )
}
