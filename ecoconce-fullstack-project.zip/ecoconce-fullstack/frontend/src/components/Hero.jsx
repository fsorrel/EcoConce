export default function Hero() {
  return (
    <section className="hero card">
      <div>
        <span className="badge">Proyecto full stack</span>
        <h2>Encuentra puntos cercanos, registra reciclaje y administra el historial de cada punto</h2>
        <p>
          El sistema solicita comunidad obligatoria, dirección opcional y ubicación GPS obligatoria para priorizar los puntos de reciclaje más cercanos.
        </p>
      </div>
      <div className="hero-grid">
        <div className="metric"><strong>GPS</strong><span>obligatorio</span></div>
        <div className="metric"><strong>Comunidad</strong><span>obligatoria</span></div>
        <div className="metric"><strong>Dirección</strong><span>opcional</span></div>
        <div className="metric"><strong>Material</strong><span>compactado</span></div>
      </div>
    </section>
  )
}
