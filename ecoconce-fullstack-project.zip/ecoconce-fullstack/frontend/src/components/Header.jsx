export default function Header({ currentView, onNavigate, user, onLogout }) {
  return (
    <header className="header">
      <div>
        <h1>EcoConce</h1>
        <p>Reciclaje inteligente con comunidad, puntos cercanos e historial operativo</p>
      </div>
      <nav className="nav">
        <button className={currentView === 'home' ? 'active' : ''} onClick={() => onNavigate('home')}>Inicio</button>
        <button className={currentView === 'register' ? 'active' : ''} onClick={() => onNavigate('register')}>Registro</button>
        <button className={currentView === 'login' ? 'active' : ''} onClick={() => onNavigate('login')}>Ingresar</button>
        {user && <button className={currentView === 'user' ? 'active' : ''} onClick={() => onNavigate('user')}>Panel usuario</button>}
        {user?.rol_id === 2 && <button className={currentView === 'admin' ? 'active' : ''} onClick={() => onNavigate('admin')}>Panel admin</button>}
        {user && <button onClick={onLogout}>Salir</button>}
      </nav>
    </header>
  )
}
