function calcularDistanciaKm(lat1, lon1, lat2, lon2) {
  const toRad = value => (value * Math.PI) / 180
  const radioTierra = 6371
  const dLat = toRad(lat2 - lat1)
  const dLon = toRad(lon2 - lon1)
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return radioTierra * c
}

export default function PointsList({ points, user, onSelectPoint }) {
  const orderedPoints = [...points].map(point => {
    if (user?.latitud && user?.longitud) {
      return {
        ...point,
        distancia: calcularDistanciaKm(Number(user.latitud), Number(user.longitud), Number(point.latitud), Number(point.longitud))
      }
    }
    return { ...point, distancia: null }
  }).sort((a, b) => {
    if (a.distancia === null) return 0
    return a.distancia - b.distancia
  })

  return (
    <section className="card">
      <h3>Puntos de reciclaje</h3>
      <div className="point-grid">
        {orderedPoints.map(point => (
          <article key={point.id} className="point-card">
            <div className="point-top">
              <h4>{point.nombre}</h4>
              <span className={`status ${point.estado}`}>{point.estado}</span>
            </div>
            <p>{point.descripcion}</p>
            <p><strong>Comunidad:</strong> {point.comunidad}</p>
            <p><strong>Dirección:</strong> {point.direccion || 'No informada'}</p>
            <p><strong>GPS:</strong> {point.latitud}, {point.longitud}</p>
            <p><strong>Distancia:</strong> {point.distancia !== null ? `${point.distancia.toFixed(2)} km` : 'Inicia sesión para priorizar cercanía'}</p>
            <button onClick={() => onSelectPoint(point)}>Ver detalle</button>
          </article>
        ))}
      </div>
    </section>
  )
}
