import { useEffect, useState } from 'react'
import Header from './components/Header'
import RegisterForm from './components/RegisterForm'
import LoginForm from './components/LoginForm'
import HomePage from './pages/HomePage'
import UserPage from './pages/UserPage'
import AdminPage from './pages/AdminPage'
import { api } from './services/api'

export default function App() {
  const [currentView, setCurrentView] = useState('home')
  const [points, setPoints] = useState([])
  const [selectedPoint, setSelectedPoint] = useState(null)
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem('ecoconce_user')
    return saved ? JSON.parse(saved) : null
  })
  const [apiStatus, setApiStatus] = useState('Conectando con la API...')

  const loadPoints = async () => {
    try {
      const pointsData = await api.getPoints()
      setPoints(pointsData)
      if (!selectedPoint && pointsData.length) {
        setSelectedPoint(pointsData[0])
      }
    } catch {
      setApiStatus('No se pudo cargar la API. Revisa backend y base de datos.')
    }
  }

  useEffect(() => {
    api.getHealth()
      .then(() => setApiStatus('API conectada correctamente'))
      .catch(() => setApiStatus('No se pudo conectar con la API'))
    loadPoints()
  }, [])

  const handleLogin = loggedUser => {
    localStorage.setItem('ecoconce_user', JSON.stringify(loggedUser))
    setUser(loggedUser)
    setCurrentView(loggedUser.rol_id === 2 ? 'admin' : 'user')
  }

  const handleLogout = () => {
    localStorage.removeItem('ecoconce_user')
    setUser(null)
    setCurrentView('home')
  }

  const handleRefreshAfterRecord = async () => {
    if (user) {
      const refreshedUser = await api.loginUser({ correo: user.correo, contrasena: user.contrasena || '123456' }).catch(() => user)
      localStorage.setItem('ecoconce_user', JSON.stringify(refreshedUser))
      setUser(refreshedUser)
    }
    loadPoints()
  }

  return (
    <div className="app-shell">
      <Header currentView={currentView} onNavigate={setCurrentView} user={user} onLogout={handleLogout} />
      <div className="status-bar">{apiStatus}</div>

      {currentView === 'home' && (
        <HomePage points={points} user={user} selectedPoint={selectedPoint} onSelectPoint={setSelectedPoint} />
      )}

      {currentView === 'register' && (
        <RegisterForm onRegister={newUser => {
          localStorage.setItem('ecoconce_user', JSON.stringify(newUser))
          setUser(newUser)
          setCurrentView('user')
        }} />
      )}

      {currentView === 'login' && <LoginForm onLogin={handleLogin} />}

      {currentView === 'user' && user && (
        <UserPage user={user} points={points} selectedPoint={selectedPoint} onSelectPoint={setSelectedPoint} onRefresh={handleRefreshAfterRecord} />
      )}

      {currentView === 'admin' && user?.rol_id === 2 && (
        <AdminPage points={points} selectedPoint={selectedPoint} onSelectPoint={setSelectedPoint} onPointCreated={loadPoints} />
      )}
    </div>
  )
}
